Bob y Alice desarrollaron un sistema criptogr�fico basado en el esquema PKCS#1 OAEP para poder compartir fotos de gatitos de forma segura. Su idea es simple. Si Bob le quiere enviar una foto a Alice, debe utilizar la clave p�blica que le pertenece a ella para cifrar el mensaje. Solo Alice con su clave privada puede descifrarlo.

Sin embargo, cometieron un peque�o error a la hora de generar sus pares de claves. Has logrado interceptar uno de sus mensajes, �podr�s descifrarlo conociendo �nicamente sus claves p�blicas?



